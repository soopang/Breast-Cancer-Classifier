%Breast Cancer Classifier
%Given an input mammogram, this program will give an output decision:
%cancerous or non-cancerous. Current accuracy is 56.67%.

%Dataset Citation:
%Suckling, J., Parker, J., Dance, D., Astley, S., Hutt, I., Boggis, C., 
%Ricketts, I., Stamatakis, E., Cerneaz, N., Kok, S., Taylor, P., Betal, D.,
%& Savage, J. (2015). Mammographic Image Analysis Society (MIAS) database 
%v1.21. Apollo - University of Cambridge Repository. 
%https://doi.org/10.17863/CAM.105113

%Specify image dataset location
imds = imageDatastore("imagestouse", ...
    IncludeSubfolders=true, ...
    LabelSource="foldernames");

%Build training data set, following 70-30 rule
numTrainFiles = 36;
[imdsTrain,imdsValidation] = splitEachLabel(imds,numTrainFiles,"randomized");

%Labels from folder names as classification results
classNames = categories(imdsTrain.Labels)


%Input images are 260x260 greyscale images
inputSize = [260 260 3];
numClasses = 2;


%Copied from example
layers = [
    imageInputLayer(inputSize)
    convolution2dLayer(5,20)
    batchNormalizationLayer
    reluLayer
    fullyConnectedLayer(numClasses)
    softmaxLayer];


%Copied from example
options = trainingOptions("sgdm", ...
    MaxEpochs=500, ...
    ValidationData=imdsValidation, ...
    ValidationFrequency=500, ...
    Plots="training-progress", ...
    Metrics="accuracy", ...
    Verbose=false);

%% 

%Train classifier
net = trainnet(imdsTrain,layers,"crossentropy",options);


%%

%Test classifer, ONLY WORKS IF YOU HAVE R2024b
accuracy = testnet(net,imdsValidation,"accuracy")

%%

%Running the classifier on a single image
%Options are "cancerous.png" and "noncancerous.png"

user_test = input("Test cancerous.png or noncancerous.png? (c/n) ",'s');

%allows user to choose which file to test when section is run
if user_test == 'c'
    test_file = "cancerous.png";
elseif user_test=='n'
    test_file = "noncancerous.png";
end

%Load the image and convert it to correct data type
image = imread(test_file);
image = single(image);

%Predict gives a classification score over all possible labels
scores = predict(net, image);
%Scores2label gives the label of the single most likely label
[label,score] = scores2label(scores,classNames)
